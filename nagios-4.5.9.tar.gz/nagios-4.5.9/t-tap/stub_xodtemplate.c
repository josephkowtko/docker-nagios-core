int xodtemplate_read_config_data(const char *main_config_file, int options) 
{ return OK; }

int xodtemplate_free_memory(void) 
{ return OK; }
